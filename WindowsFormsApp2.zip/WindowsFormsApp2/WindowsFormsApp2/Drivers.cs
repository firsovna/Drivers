namespace WindowsFormsApp2
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class Drivers
    {
        public int? ID { get; set; }

        [StringLength(50)]
        public string Фамилия { get; set; }

        [StringLength(50)]
        public string Имя { get; set; }

        [StringLength(50)]
        public string Отчество { get; set; }

        [Column("Паспорт (серия и номер)")]
        [StringLength(50)]
        public string Паспорт__серия_и_номер_ { get; set; }

        [Column("Адрес регистрации")]
        [StringLength(50)]
        public string Адрес_регистрации { get; set; }

        [Column("Адрес проживания")]
        [StringLength(50)]
        public string Адрес_проживания { get; set; }

        [Key]
        [Column("Место работы", Order = 0)]
        [StringLength(50)]
        public string Место_работы { get; set; }

        [Key]
        [Column(Order = 1)]
        [StringLength(50)]
        public string Должность { get; set; }

        [Column("Мобильный телефон")]
        [StringLength(50)]
        public string Мобильный_телефон { get; set; }

        [StringLength(50)]
        public string Email { get; set; }

        [StringLength(50)]
        public string Фотография { get; set; }

        [Key]
        [Column(Order = 2)]
        [StringLength(50)]
        public string Замечания { get; set; }
    }
}
