namespace WindowsFormsApp2
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("Order details")]
    public partial class Order_details
    {
        [Key]
        [StringLength(10)]
        public string Detail_ID { get; set; }

        [Required]
        [StringLength(10)]
        public string Accessory_ID { get; set; }

        [Required]
        [StringLength(10)]
        public string Order_ID { get; set; }
    }
}
